﻿function clearForm() {
    //--- TODO: escrever o código em falta aqui...
}

function clearAnswers() {
    //--- TODO: escrever o código em falta aqui...
}

function clearAnswer(q) {
    //--- TODO: escrever o código em falta aqui...
}

function checkStatus() {
    //--- TODO: escrever o código em falta aqui...
}
